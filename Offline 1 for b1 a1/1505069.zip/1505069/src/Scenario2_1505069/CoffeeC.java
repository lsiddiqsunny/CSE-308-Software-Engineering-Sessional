package Scenario2_1505069;

public class CoffeeC implements Coffee {
    @Override
    public String haveSugar() {
        return "Coffee C with  sugar";
    }
}
