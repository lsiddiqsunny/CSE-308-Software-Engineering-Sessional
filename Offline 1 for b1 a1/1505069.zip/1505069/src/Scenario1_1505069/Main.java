package Scenario1_1505069;

public class Main {

    public static void main(String[] args) {

        Burger burger=BurgerBuilder.prepareBurger();
    }
}
