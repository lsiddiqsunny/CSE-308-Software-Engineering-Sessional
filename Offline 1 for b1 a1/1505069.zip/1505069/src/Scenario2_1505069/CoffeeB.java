package Scenario2_1505069;

public class CoffeeB implements Coffee {
    @Override
    public String haveSugar() {
        return "Coffee B with no sugar";
    }
}
