package Scenario1_1505069;

public interface BurgerItem {
    public String patty();
    public String sauce();
    public String cheese();
    public float price();
    public String burgername();
}

