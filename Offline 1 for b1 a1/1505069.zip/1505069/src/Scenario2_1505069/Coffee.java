package Scenario2_1505069;

public interface Coffee {
    public String haveSugar();
}
