package Scenario1_1505069;

public abstract class BeefBurger implements BurgerItem {
}
