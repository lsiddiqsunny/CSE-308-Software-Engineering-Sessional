package Scenario2_1505069;

public class getCoffeeMaker {
    private static CoffeeMaker cm=new CoffeeMaker();
    private getCoffeeMaker(){

    }
    public static CoffeeMaker getCoffeeshop(){
        return cm;

    }

}
